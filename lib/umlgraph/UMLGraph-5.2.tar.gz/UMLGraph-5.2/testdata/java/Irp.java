// $Id: Irp.java,v 1.1 2005/11/23 22:18:45 dds Exp $
class Application {}

class IrpApplication extends Application {}

/** @depend - <friend> - IrpApplication */
class Main {}
