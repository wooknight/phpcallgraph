package gr.spinellis.basic.views;

/**
 * @view
 * @opt hide
 *
 * @match class (gr.spinellis.basic.*|java.*)
 * @opt !hide
 * @match class .*
 * @opt nodefillcolor gray
 * @match class gr.spinellis.*
 * @opt nodefillcolor yellow
 */
public class ViewColors {
}
